const searchBtn = document.querySelector('#btn');

//display error message
const hideError = () => {
	document.querySelector('#error').style.display = 'none';
}

//attch the hideError function to the button
document.querySelector('#errorBtn').addEventListener('click', hideError);

//fetches API
const fetchAPI = (endpoint, callback) => {
	// new XMLHttpRequest
	const api = new XMLHttpRequest();
	api.addEventListener('readystatechange', () => {
		// condition
		if (api.readyState === 4 && api.status === 200) {
			// parsing result
			const data = JSON.parse(api.responseText);
			// callback
			callback(undefined, data);
		}
		else if (api.readyState === 4 ){
			const error = document.querySelector('#error');
			error.style.display = 'flex';
		}
	})
	// send request
	api.open('GET', endpoint);
	api.send();
}



// onclick element:searchBtn
searchBtn.addEventListener('click', () => {
	//get the input field
	const searchField = document.querySelector('#searchField');
	//keyword
	const keyword = 'https://api.dictionaryapi.dev/api/v2/entries/en/' + searchField.value;

	// fetch the api
	fetchAPI(keyword, (err, data) => {
		//get the div to display results
		document.querySelector('#apiResult').innerHTML = data.map((result, key) => {

			//first index of array
			if (key === 0) {
				const {word, phonetics, meanings} = result; //object array

				// html template using 
				return `
					<div>
						<!-- searched word or keyword -->
						<h2 class='block__keyword'>${word}</h2>
						${
							//map through the phonetic array
							phonetics.map((phonetic, key) => {
								const {text: text, audio: audio} = phonetic;//saving array of phonetic
								//conditional statement: if text and audio is found
								if (text && audio) {
									return `
										<div class='phonetics'>
											<p class='phonetics__text'>${text}</p>
											<audio controls>
												<source src=${audio} type='audio/mpeg'/>
											</audio>
										</div>
									`
								}
							}).join('')
						}

						${
							meanings.map((meaning, key) => {
								const {partOfSpeech, definitions, synonyms, antonyms} = meaning;
								return `
									<div class='meanings'>
										<h6 class='meanings__heading'>
											${partOfSpeech}
										</h6>

										${definitions.map((mapResult, key) => {
											return `
												<p class='meanings__def'>
													${key + 1 + '.'} ${mapResult.definition}
												</p>
											`
										}).join('')}

										<p class='meanings__synonyms'>
											Similar: ${synonyms.length > 0 ? synonyms.join(', ') : 'No related  word found'}
										</p>
									</div>
								`
							}).join('')
						}	
					</div>
	 			`	
			}
	 	}).join('')
	})
	
});

